# DiscordBotAltyapi
// MAKE BY RAKSİX

ayarlar.json dosyasını düzenleyen yeter

// MAKE BY RAKSİX
# DiscordBotAltyapi
